#pragma once
class ParticleInheritance
{
};

