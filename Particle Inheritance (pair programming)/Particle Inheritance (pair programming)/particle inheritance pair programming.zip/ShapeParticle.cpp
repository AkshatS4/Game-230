#include "ShapeParticle.h"

using namespace sf;
using namespace gm;

ShapeParticle::ShapeParticle() : shape(nullptr) {}

void ShapeParticle::getShape() const override 
{

}